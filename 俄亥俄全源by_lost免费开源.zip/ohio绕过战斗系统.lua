bypass:Button({
    Title = "绕过战斗状态系统",
    Callback = function()
        for _, func in pairs(getgc(true)) do
    if type(func) == "function" then
        local info = debug.getinfo(func)
        if info.name == "isInCombat" or (info.source and info.source:find("combatIndicator")) then
            hookfunction(func, function() 
                return false 
            end)
        end
    end
end
    end
})