WSJ:Toggle({
    Title = "自动抢银行",
    --Image = "bird",
    Value = false,
    Callback = function(state) 
    autobank = state
    end
})