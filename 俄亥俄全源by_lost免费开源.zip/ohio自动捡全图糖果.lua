WSJ:Toggle({
    Title = "自动捡全图糖果",
    --Image = "bird",
    Value = false,
    Callback = function(state) 
    autocandy = state
    end
})