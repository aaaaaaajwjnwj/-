bypass:Slider({
    Title = "辅助瞄准数值",
    Value = {
        Min = 1,
        Max = 20,
        Default = 1,
    },
    Callback = function(value) 
game:GetService("Players").LocalPlayer:SetAttribute("aimAssistSensitivity", value)
    end
})